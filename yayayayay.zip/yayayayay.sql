create database banco_exemplo_dml2922;

use banco_exemplo_dml2922;

-- safe update mode" bloqueia UPDATE/DELETE
set sql_safe_updates =0;

-- cliente da loja
create table clientes (
	id int auto_increment primary key,
	nome varchar(100),
    email varchar(100),
    cidade varchar(100),
    estado char(2),
    data_cadastro date
);

-- produtos vendidos
create table produtos (
	id int auto_increment primary key,
    nome varchar(100),
    categoria varchar(50),
    preco decimal(10,2),
    estoque int
);

-- pedidos feitos pelos clientes
create table pedidos (
	id int auto_increment primary key,
    cliente_id int,
    data_pedido date,
    status varchar(20),
    foreign key (cliente_id) references clientes(id)
);

-- itens de cada pedido (1 pedi pode ter var prod)
create table itens_pedidos(
	id int auto_increment primary key, 
    pedido_id int,
    produto_id int,
    quantidade int,
    preco_unitario decimal(10,2), -- preço no momento da venda
    foreign key (pedido_id) references pedidos(id),
    foreign key (produto_id) references produtos(id)
);

#1. INSERT - inserindo dados
insert into clientes (nome, email, cidade, estado, data_cadastro)
values ('Carlos Silva', 'carlos@email.com', 'são paulo', 'SP', '2025-01-15');

insert into clientes (nome, email, cidade, estado, data_cadastro)
values ('Ana Souza', null, 'curitiba', 'PR', '2025-02-20');

insert into produtos (nome, categoria, preco, estoque)
values ('Notebook', 'Informatica', 3500.00, 10),
		('Cadeira gamer', 'Moveis', 1200.00, 5);
        
insert into pedidos (cliente_id, data_pedido, status)
values (1, '2025-07-01', 'Enviado'),
		(1, '2025-09-02', 'pendente');
        
insert into itens_pedidos (pedido_id, produto_id, quantidade, preco_unitario)
values (1, 1, 1, 3500.00),
		(2, 2, 2, 1200.00);
        
select * from pedidos;

#2. SELECT - consultas básicas

-- 2.1 Todas colunas
select * from clientes;

-- 2.2 apenas colunas especificcas
select nome, cidade from clientes;

-- 2.3 apelidos(AS) e colunas calculadas
select nome as produto, preco as  preco_atual,
	preco * estoque as valor_em_estoque
from produtos;

-- 3.1 igualdade
select * from clientes
where cidade = 'são paulo';

-- 3.2 comparaçãoptimize
select nome, preco from produtos
where preco > 2000; -- notebook

-- 3.3 AND: as duas condições precisam ser verdadeiras
select nome, preco, estoque from produtos
where preco > 1000 and estoque < 10; -- Cadeira Gamer

-- 3.4 OR; Basta uma ser verdadeira
select nome, categoria, preco from produtos
where categoria = 'Móveis' or preco > 3000; -- os dois produtos
